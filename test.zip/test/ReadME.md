We need to run our application with any server or webstrom.

index.html for running the application.

if you want to run tests then we have to run specRunner.html.
